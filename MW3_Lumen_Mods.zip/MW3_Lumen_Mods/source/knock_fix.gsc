#using scripts\common\system;
#using scripts\mp\gametypes\br_pickups;

// =====================================================================
//  knock_fix  (Lumen / MWIII 1.21, WARZONE ONLY -> Custom\wz2)
//  - Knocked players can be finished: removes the knock invulnerability
//    after 1 second (MW3 normally clears it itself, but it was sticking).
//  - Everyone gets a self-revive every time they spawn in.
//  - No fall damage for anyone.
//  - Fix for the bots mod (matchstats.gscc): its damage hook ignores ALL
//    damage on knocked players. For knocked players only, damage is sent
//    straight to the game's original handler instead.
//  Same skeleton as jero_infinite_tac_sprint (known working).
// =====================================================================

function private autoexec __init__system__()
{
    system::register( #"knock_fix", undefined, undefined, &__init__ );
}

function __init__()
{
    level thread [[ &kf_boot ]]();
}

function init()
{
    level thread [[ &kf_boot ]]();
}

function main()
{
    level thread [[ &kf_boot ]]();
}

function kf_boot()
{
    level endon( "game_ended" );

    if ( isdefined( level.kf_booted ) )
    {
        return;
    }

    level.kf_booted = 1;

    system::function_3f680182ad0b9ef7();

    for ( ;; )
    {
        // knock invulnerability should only last about 1 second
        if ( !isdefined( level.laststandinvulntime ) || level.laststandinvulntime > 1 )
        {
            level.laststandinvulntime = 1;
        }

        kf_hook_damage();

        if ( isdefined( level.players ) )
        {
            foreach ( player in level.players )
            {
                if ( !isdefined( player ) || !isplayer( player ) || isdefined( player.kf_hooked ) )
                {
                    continue;
                }

                player.kf_hooked = 1;
                player thread [[ &kf_player_loop ]]();
                player thread [[ &kf_spawn_watch ]]();
            }
        }

        wait 0.5;
    }
}

// ---------------------------------------------------------------------
//  Knocked players can be finished
// ---------------------------------------------------------------------

function kf_player_loop()
{
    self endon( "disconnect" );
    level endon( "game_ended" );

    for ( ;; )
    {
        kf_check_knocked();
        wait 0.25;
    }
}

function kf_check_knocked()
{
    if ( !isalive( self ) || !isdefined( self.inlaststand ) || !self.inlaststand )
    {
        return;
    }

    if ( !isdefined( self.laststandstarttime ) || gettime() - self.laststandstarttime < 1000 )
    {
        return;
    }

    // the game stores the knock protection as a damage modifier; clear it
    if ( isdefined( self.multiplicativedamagemodifiers ) )
    {
        self.multiplicativedamagemodifiers[ "last_stand_invuln" ] = undefined;
    }

    if ( isdefined( self.multiplicativedamagemodifierignorefuncs ) )
    {
        self.multiplicativedamagemodifierignorefuncs[ "last_stand_invuln" ] = undefined;
    }

    if ( isdefined( self.additivedamagemodifiers ) )
    {
        self.additivedamagemodifiers[ "last_stand_invuln" ] = undefined;
    }

    if ( isdefined( self.additivedamagemodifierignorefuncs ) )
    {
        self.additivedamagemodifierignorefuncs[ "last_stand_invuln" ] = undefined;
    }
}

// ---------------------------------------------------------------------
//  Self-revive on every spawn
// ---------------------------------------------------------------------

function kf_spawn_watch()
{
    self endon( "disconnect" );
    level endon( "game_ended" );

    // in case they are already alive when the script starts
    if ( isalive( self ) )
    {
        kf_give_self_revive();
    }

    for ( ;; )
    {
        self waittill( "spawned_player" );
        wait 1;
        kf_give_self_revive();
    }
}

function kf_give_self_revive()
{
    if ( !isalive( self ) )
    {
        return;
    }

    // already holding one
    if ( isdefined( self.var_6c05b62d5521a0b2 ) )
    {
        return;
    }

    // same call the game uses when you pick up a self-revive (1 = no splash)
    br_pickups::addselfrevivetoken( 1 );
}

// ---------------------------------------------------------------------
//  Bypass the bots mod's "knocked = no damage" block
// ---------------------------------------------------------------------

function kf_hook_damage()
{
    // the bots mod keeps the game's original player-damage handler here
    // once it has installed its own wrapper
    if ( !isdefined( level.var_d38d7ac0946be2b2 ) || !isdefined( level.var_4ca9a0095111e38a ) )
    {
        return;
    }

    if ( !isdefined( level.kf_game_damage ) )
    {
        level.kf_game_damage = level.var_d38d7ac0946be2b2;
    }

    if ( level.var_4ca9a0095111e38a == &kf_damage )
    {
        return;
    }

    level.kf_prev_damage = level.var_4ca9a0095111e38a;
    level.var_4ca9a0095111e38a = &kf_damage;
}

function kf_damage( a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15 )
{
    if ( !isdefined( self ) )
    {
        return;
    }

    // no fall damage (a5 = means of death)
    if ( isdefined( a5 ) && a5 == "MOD_FALLING" )
    {
        return;
    }

    // knocked: go straight to the game's own damage code so they can be finished
    if ( isdefined( self.inlaststand ) && self.inlaststand && isdefined( level.kf_game_damage ) )
    {
        self [[ level.kf_game_damage ]]( a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15 );
        return;
    }

    // loop guard: if we are re-entered, hand off to the game's handler
    if ( isdefined( self.kf_in_damage ) && isdefined( level.kf_game_damage ) )
    {
        self [[ level.kf_game_damage ]]( a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15 );
        return;
    }

    if ( !isdefined( level.kf_prev_damage ) )
    {
        return;
    }

    self.kf_in_damage = 1;
    self [[ level.kf_prev_damage ]]( a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15 );
    self.kf_in_damage = undefined;
}
