#using scripts\common\system;

// =====================================================================
//  host_kick  (Lumen / MWIII 1.21, multiplayer + warzone)
//  Host console commands (~):
//    set kick_list 1        shows everyone's number and name on screen
//    set kick_num 5         kicks player number 5
//    set kick_name bob      kicks anyone whose name contains "bob"
//  The host can never be kicked by these. Each command resets itself.
//  Same skeleton as jero_infinite_tac_sprint (known working).
// =====================================================================

function private autoexec __init__system__()
{
    system::register( #"host_kick", undefined, undefined, &__init__ );
}

function __init__()
{
    level thread [[ &hk_boot ]]();
}

function init()
{
    level thread [[ &hk_boot ]]();
}

function main()
{
    level thread [[ &hk_boot ]]();
}

function hk_boot()
{
    level endon( "game_ended" );

    if ( isdefined( level.hk_booted ) )
    {
        return;
    }

    level.hk_booted = 1;

    system::function_3f680182ad0b9ef7();

    setdvar( @"kick_list", 0 );
    setdvar( @"kick_num", -1 );
    setdvar( @"kick_name", "" );

    for ( ;; )
    {
        wait 0.5;

        if ( !isdefined( level.players ) )
        {
            continue;
        }

        if ( getdvarint( @"kick_list", 0 ) == 1 )
        {
            setdvar( @"kick_list", 0 );
            hk_show_list();
        }

        num = getdvarint( @"kick_num", -1 );

        if ( num >= 0 )
        {
            setdvar( @"kick_num", -1 );
            hk_kick_by_num( num );
        }

        name = getdvar( @"kick_name", "" );

        if ( isdefined( name ) && name != "" )
        {
            setdvar( @"kick_name", "" );
            hk_kick_by_name( tolower( name ) );
        }
    }
}

function hk_show_list()
{
    foreach ( player in level.players )
    {
        if ( !isdefined( player ) || !isplayer( player ) || !player ishost() )
        {
            continue;
        }

        foreach ( p in level.players )
        {
            if ( isdefined( p ) && isplayer( p ) && isdefined( p.name ) )
            {
                player iprintln( "^3" + p getentitynumber() + "^7  " + p.name );
            }
        }
    }
}

function hk_kick_by_num( num )
{
    foreach ( p in level.players )
    {
        if ( !isdefined( p ) || !isplayer( p ) || p ishost() )
        {
            continue;
        }

        if ( p getentitynumber() == num )
        {
            kick( num, "EXE/PLAYERKICKED" );
            return;
        }
    }
}

function hk_kick_by_name( part )
{
    targets = [];

    foreach ( p in level.players )
    {
        if ( !isdefined( p ) || !isplayer( p ) || p ishost() || !isdefined( p.name ) )
        {
            continue;
        }

        if ( issubstr( tolower( p.name ), part ) )
        {
            targets[ targets.size ] = p getentitynumber();
        }
    }

    foreach ( num in targets )
    {
        kick( num, "EXE/PLAYERKICKED" );
    }
}
