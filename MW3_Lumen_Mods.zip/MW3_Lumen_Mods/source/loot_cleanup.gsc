#using scripts\common\system;

// =====================================================================
//  loot_cleanup v3  (Lumen / MWIII 1.21, WARZONE ONLY -> Custom\wz2)
//  No loot drops when a player (or AI) dies.
//  Uses MW3's own switch: the game's death-drop code
//  (br_pickups::droponplayerdeath) exits immediately when this dvar is 1,
//  so the loot is never spawned at all - nothing to clean up, no extra
//  network traffic.
// =====================================================================

function private autoexec __init__system__()
{
    system::register( #"loot_cleanup", undefined, undefined, &__init__ );
}

function __init__()
{
    level thread [[ &lc_boot ]]();
}

function init()
{
    level thread [[ &lc_boot ]]();
}

function main()
{
    level thread [[ &lc_boot ]]();
}

function lc_boot()
{
    level endon( "game_ended" );

    if ( isdefined( level.lc_booted ) )
    {
        return;
    }

    level.lc_booted = 1;

    // set it right away, then keep it set in case the mode resets it
    for ( ;; )
    {
        setdvar( @"hash_307fc239dc43be41", 1 );
        wait 5;
    }
}
