#using scripts\common\system;

// =====================================================================
//  host_equipment_stim  (Lumen / MWIII 1.21)
//  Built on the same skeleton as jero_infinite_tac_sprint (known working).
//  Defaults (on at launch): inf tac ON, inf lethal ON, stim boost ON 1.3x for 7s
//  Change in the console (~) any time:
//
//    set inf_tac 0/1      infinite tacticals (stims etc.)
//    set inf_lethal 0/1   infinite lethals
//    set stim_on 0/1      stim speed boost
//    set stim_speed 1.3   speed while stimmed (1.0 = normal)
//    set stim_time 7      seconds the boost lasts
// =====================================================================

function private autoexec __init__system__()
{
    system::register( #"host_equipment_stim", undefined, undefined, &__init__ );
}

function __init__()
{
    level thread [[ &hes_boot ]]();
}

function init()
{
    level thread [[ &hes_boot ]]();
}

function main()
{
    level thread [[ &hes_boot ]]();
}

function hes_boot()
{
    level endon( "game_ended" );

    if ( isdefined( level.hes_booted ) )
    {
        return;
    }

    level.hes_booted = 1;

    // wait until the game's systems are done loading (same as jero)
    system::function_3f680182ad0b9ef7();

    setdvarifuninitialized( @"inf_tac", 1 );
    setdvarifuninitialized( @"inf_lethal", 1 );
    setdvarifuninitialized( @"stim_on", 1 );
    setdvarifuninitialized( @"stim_speed", 1.3 );
    setdvarifuninitialized( @"stim_time", 7 );

    for ( ;; )
    {
        if ( isdefined( level.players ) )
        {
            foreach ( player in level.players )
            {
                if ( !isdefined( player ) || !isplayer( player ) || isdefined( player.hes_hooked ) )
                {
                    continue;
                }

                player.hes_hooked = 1;
                player thread [[ &hes_player_loop ]]();
                player thread [[ &hes_stim_watch ]]();
            }
        }

        wait 0.5;
    }
}

function hes_player_loop()
{
    self endon( "disconnect" );
    level endon( "game_ended" );

    for ( ;; )
    {
        hes_tick();
        wait 0.25;
    }
}

function hes_tick()
{
    if ( !isalive( self ) || !isdefined( self.sessionstate ) || self.sessionstate != "playing" )
    {
        self.hes_stim_until = undefined;
        return;
    }

    // ---- infinite equipment ----
    if ( getdvarint( @"inf_lethal", 1 ) == 1 )
    {
        hes_fill_slot( "primary" );
    }

    if ( getdvarint( @"inf_tac", 1 ) == 1 )
    {
        hes_fill_slot( "secondary" );
    }

    // ---- stim speed boost ----
    if ( isdefined( self.hes_stim_until ) )
    {
        if ( gettime() < self.hes_stim_until && getdvarint( @"stim_on", 1 ) == 1 )
        {
            speed = getdvarfloat( @"stim_speed", 1.3 );

            if ( speed < 0.1 )
            {
                speed = 0.1;
            }

            if ( speed > 5 )
            {
                speed = 5;
            }

            self setmovespeedscale( speed );
        }
        else
        {
            self.hes_stim_until = undefined;
            self setmovespeedscale( 1.0 );
        }
    }
}

// slot: "primary" = lethal, "secondary" = tactical
function hes_fill_slot( slot )
{
    if ( !isdefined( self.equipment ) || !isdefined( self.equipment[ slot ] ) )
    {
        return;
    }

    if ( !isdefined( level.equipment ) || !isdefined( level.equipment.table ) )
    {
        return;
    }

    info = level.equipment.table[ self.equipment[ slot ] ];

    if ( !isdefined( info ) || !isdefined( info.objweapon ) )
    {
        return;
    }

    offhands = self getweaponslistoffhands();

    if ( !isdefined( offhands ) )
    {
        return;
    }

    foreach ( w in offhands )
    {
        if ( w.basename == info.objweapon.basename )
        {
            self givemaxammo( w );
            self setweaponammoclip( w, weaponclipsize( w ) );
        }
    }
}

function hes_stim_watch()
{
    self endon( "disconnect" );
    level endon( "game_ended" );

    for ( ;; )
    {
        self waittill( "offhand_fired", weapon );

        if ( hes_is_stim( weapon ) )
        {
            self.hes_stim_until = gettime() + int( getdvarfloat( @"stim_time", 7 ) * 1000 );
        }
    }
}

function hes_is_stim( weapon )
{
    if ( !isdefined( weapon ) || !isdefined( weapon.basename ) )
    {
        return false;
    }

    if ( isdefined( level.equipment ) && isdefined( level.equipment.table ) && isdefined( level.equipment.table[ "equip_adrenaline" ] ) && isdefined( level.equipment.table[ "equip_adrenaline" ].objweapon ) )
    {
        if ( weapon.basename == level.equipment.table[ "equip_adrenaline" ].objweapon.basename )
        {
            return true;
        }
    }

    return issubstr( weapon.basename, "adrenaline" ) || issubstr( weapon.basename, "stim" );
}
