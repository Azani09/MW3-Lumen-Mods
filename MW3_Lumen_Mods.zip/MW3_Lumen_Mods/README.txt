MW3 LUMEN MODS  (Modern Warfare III 1.21 / Lumen private server)
=================================================================

CONTACT / VIDEO TUTORIAL / SCRIPT REQUESTS
  Discord:  goofy.10
  YouTube:  realjordanhq   (video install tutorial)
  Questions, bug reports or script requests -> message me on Discord.

CONTENTS
  1. What's included
  2. Requirements
  3. Install
  4. Lobby commands (instant finishes, daytime Rebirth)
  5. Mod commands (stims, lethals, kick)
  6. Changing the stim speed / time - DETAILED
  7. Notes
  8. Uninstall
  9. Rebuilding from source
 10. Credits


1. WHAT'S INCLUDED
------------------
Multiplayer + Warzone:
  host_equipment_stim  - Infinite tacticals (stims etc.) and infinite lethals
                         Stim speed boost: 1.3x speed for 7 seconds
  host_kick            - Host can kick players from the console

Warzone only:
  knock_fix            - Knocked (downed) players can be finished
                         "Hold to give up" works
                         Everyone spawns with a self-revive
                         No fall damage
  loot_cleanup         - No loot drops when players die (less server load)


WHICH MODES EACH FEATURE WORKS IN
  Feature                          Multiplayer   Warzone
  -------------------------------  -----------   -------
  Infinite tacticals (stims etc.)      YES          YES
  Infinite lethals                     YES          YES
  Stim speed boost (1.3x / 7s)         YES          YES
  Host kick commands                   YES          YES
  Finish knocked players               n/a *        YES
  "Hold to give up" works              n/a *        YES
  Self-revive on every spawn           NO           YES
  No fall damage                       NO           YES
  No loot drops on death               NO           YES
  Infinite tactical sprint             -- separate mod by Jero (wz2), not included --

  * Normal multiplayer modes have no knocked/downed state.
  Multiplayer files go in   Custom\mp
  Warzone files go in       Custom\wz2
  (host_equipment_stim and host_kick come in BOTH folders - copy both
   if you want them in both modes)

2. REQUIREMENTS
---------------
- Lumen MW3 1.21 build, launched with _StartGame_Rel.bat
- In jupiter\settings.json:  "customGscEnabled": true
- Only the HOST needs these files. Players joining don't.


3. INSTALL
----------
1. Close the game completely.
2. Open your game folder (the one with cod23-cod.exe and _StartGame_Rel.bat).
3. Copy the "jupiter" folder from this zip into your game folder.
   If Windows asks, choose "Replace" / "Merge" - it only ADDS these files:

     jupiter\Assets\Scripts\Custom\mp\host_equipment_stim.gscc
     jupiter\Assets\Scripts\Custom\mp\host_kick.gscc
     jupiter\Assets\Scripts\Custom\wz2\host_equipment_stim.gscc
     jupiter\Assets\Scripts\Custom\wz2\host_kick.gscc
     jupiter\Assets\Scripts\Custom\wz2\knock_fix.gscc
     jupiter\Assets\Scripts\Custom\wz2\loot_cleanup.gscc

4. Launch with _StartGame_Rel.bat and host a match.

Don't want a feature? Just don't copy that file (or delete it later).
Each file works on its own.


4. LOBBY COMMANDS
-----------------
Open the console with the ~ key (the bar at the top of the screen),
type the command, press Enter. Do this IN THE LOBBY, before the match
starts.

INSTANT FINISHES (executions happen instantly instead of the long hold):
    execution_hold_duration 0.00

DAYTIME REBIRTH ISLAND:
    Step 1: In the lobby, choose the map/mode "Hellspawn Purgatory".
    Step 2: Open the console (~) and enter these two lines, one at a time:
              ui_mapname mp_jup_escape5
              br_minplayers 0
    ui_mapname mp_jup_escape5  -> loads Rebirth Island in daytime
    br_minplayers 0            -> lets the match start without a full lobby

Tip: these lobby commands reset when you close the game, so enter them
again each time you host.


5. MOD COMMANDS (press ~ as host, any time during a match)
----------------------------------------------------------
  set inf_tac 0          turn infinite tacticals OFF   (1 = on, default on)
  set inf_lethal 0       turn infinite lethals OFF     (1 = on, default on)
  set stim_on 0          turn the stim speed boost OFF (1 = on, default on)
  set stim_speed 1.3     how fast you move while stimmed
  set stim_time 7        how many seconds the boost lasts

  set kick_list 1        show every player's number + name on screen
  set kick_num 5         kick player number 5 (use kick_list first)
  set kick_name bob      kick anyone whose name contains "bob"
                         (capital letters don't matter; the host can
                         never be kicked)

Commands take effect immediately and reset themselves (kick commands)
or last until you close the game (stim / equipment settings).

Note: if "sv_cheats" is false in jupiter\settings.json, the console may
block "set". Everything still works from the built-in defaults.


6. CHANGING THE STIM SPEED / TIME - DETAILED
--------------------------------------------
There are two ways: TEMPORARY (console, lasts until you close the game)
or PERMANENT (change the default and rebuild the file).

---- A) TEMPORARY - from the console ----------------------------------

1. Host a match.
2. Press ~ to open the console.
3. Type one of these and press Enter:

     set stim_speed 1.5     -> 1.5x speed
     set stim_time 10       -> boost lasts 10 seconds

4. Pop a stim - the new values apply right away. Changing them while a
   boost is active also applies right away.

What the numbers mean:
   stim_speed
     1.0  = normal speed (no boost)
     1.3  = 30% faster  (default)
     1.5  = 50% faster
     2.0  = double speed (very fast)
     Allowed range: 0.1 to 5. Anything outside is clamped.
   stim_time
     Seconds the boost lasts after popping a stim. Default 7.
     Popping another stim during the boost restarts the timer.

Other switches:
     set stim_on 0     -> no speed boost at all (stims just heal)
     set stim_on 1     -> boost back on

---- B) PERMANENT - change the defaults --------------------------------

You need: Atian Tools (ACTS) - download acts.zip from
https://github.com/ate47/atian-cod-tools/releases and extract it.
acts.exe is inside the "bin" folder.

1. Open source\host_equipment_stim.gsc from this zip in Notepad.

2. Find these lines near the top (inside "hes_boot"):

     setdvarifuninitialized( @"inf_tac", 1 );
     setdvarifuninitialized( @"inf_lethal", 1 );
     setdvarifuninitialized( @"stim_on", 1 );
     setdvarifuninitialized( @"stim_speed", 1.3 );
     setdvarifuninitialized( @"stim_time", 7 );

   Change the numbers to what you want. Example - 1.5x for 10 seconds:

     setdvarifuninitialized( @"stim_speed", 1.5 );
     setdvarifuninitialized( @"stim_time", 10 );

3. Further down there are "fallback" numbers. Change them to match:

     speed = getdvarfloat( @"stim_speed", 1.3 );        -> 1.5
     ... getdvarfloat( @"stim_time", 7 ) * 1000 ...      -> 10

   (Also inf_tac / inf_lethal / stim_on have a matching 1 in a
   getdvarint(...) line if you change those defaults.)

4. Save the file. Copy it into the ACTS "bin" folder (next to acts.exe).

5. Open that bin folder, click the address bar, type cmd, press Enter.
   In the black window, run these TWO commands (one for multiplayer,
   one for Warzone):

     acts.exe gscc -g jup -p pc --name "custom/mp/host_equipment_stim.gsc" -o host_mp host_equipment_stim.gsc
     acts.exe gscc -g jup -p pc --name "custom/wz2/host_equipment_stim.gsc" -o host_wz host_equipment_stim.gsc

   Each should say "Done into ... (jup/PC)".

6. Close the game. Copy and rename:
     host_mp.gscc -> jupiter\Assets\Scripts\Custom\mp\host_equipment_stim.gscc
     host_wz.gscc -> jupiter\Assets\Scripts\Custom\wz2\host_equipment_stim.gscc
   (replace the old files)

7. Launch the game. Your new defaults are active every time.

IMPORTANT: the --name in step 5 MUST match the folder the file goes in
("custom/mp/..." for the mp folder, "custom/wz2/..." for wz2), or the
game ignores the file.


7. NOTES
--------
- The knock fix and no-fall-damage work by hooking the damage handler
  installed by the Warzone bots mod (matchstats.gscc). Without that bots
  mod, knock_fix still gives self-revives, but the other parts do nothing
  (they're not needed - the base game lets you finish downed players).
- The kick tool and the newest loot_cleanup were tested less than the
  rest. If anything misbehaves, delete that one .gscc file.
- If the game crashes at match start, remove the files one at a time to
  find which one.


8. UNINSTALL
------------
Delete the .gscc files listed in step 3 from
jupiter\Assets\Scripts\Custom\mp and \wz2.


9. REBUILDING FROM SOURCE (any file)
------------------------------------
The "source" folder has the readable code for every mod. Same steps as
6B, with the matching name:

  acts.exe gscc -g jup -p pc --name "custom/<mp or wz2>/<name>.gsc" -o <name> <name>.gsc

  host_equipment_stim  -> mp AND wz2
  host_kick            -> mp AND wz2
  knock_fix            -> wz2 only
  loot_cleanup         -> wz2 only


10. CREDITS
-----------
Compiled with Atian Tools (ACTS) by ate47.
Infinite tactical sprint (jero_infinite_tac_sprint) is a separate mod by
Jero and is not included here - get it from its original source.


CONTACT
-------
Made by goofy.10
  Discord:  goofy.10
  YouTube:  realjordanhq  - video tutorial + script requests

LICENSE (short version - full text in LICENSE)
---------------------------------------------
All rights reserved, goofy.10. Free to download and use on your own
server. You may NOT sell it, re-upload/share the files, or make videos,
tutorials or other content about it without permission. Send people to
the official realjordanhq video instead.
